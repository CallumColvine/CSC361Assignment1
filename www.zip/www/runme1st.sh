#!/bin/sh
chmod 200 cantRead
